package com.carter.infinitewave

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

class MainActivity : Activity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 7, 20)
        window.navigationBarColor = Color.rgb(8, 7, 20)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        setContentView(InfiniteWaveView(this))
    }
}

private class InfiniteWaveView(context: Context) : View(context) {
    private enum class Screen { MENU, LEVELS, WAVES, PLAY, PAUSE, DEAD, COMPLETE }

    private data class Level(
        val title: String,
        val speed: Float,
        val gap: Float,
        val duration: Float
    )
    private data class Obstacle(val x: Float, val top: Boolean)
    private data class Coin(val x: Float, val y: Float, var taken: Boolean = false)
    private data class TrailPoint(val x: Float, val y: Float)

    private val levels = listOf(
        Level("BEGINNER", 300f, 245f, 35f),
        Level("EASY", 350f, 220f, 45f),
        Level("NORMAL", 410f, 195f, 55f),
        Level("HARD", 475f, 170f, 65f),
        Level("EXTREME", 540f, 150f, 75f)
    )
    private val colors = intArrayOf(
        Color.rgb(171, 111, 255),
        Color.rgb(0, 224, 255),
        Color.rgb(255, 75, 157),
        Color.rgb(79, 255, 174),
        Color.rgb(255, 194, 76),
        Color.rgb(255, 255, 255)
    )
    private val prefs = context.getSharedPreferences("infinite_wave", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var screen = Screen.MENU
    private var levelIndex = 0
    private var waveIndex = 0
    private var playerY = 250f
    private var holding = false
    private var elapsed = 0f
    private var worldX = 0f
    private var distance = 0f
    private var nextObstacle = 700f
    private var nextCoin = 900f
    private var runCoins = 0
    private var best = prefs.getInt("best", 0)
    private var totalCoins = prefs.getInt("coins", 0)
    private var unlockedLevels = prefs.getInt("unlocked", 1)
    private var lastFrame = 0L
    private var anim = 0f

    private val obstacles = mutableListOf<Obstacle>()
    private val coins = mutableListOf<Coin>()
    private val trail = mutableListOf<TrailPoint>()

    private val virtualW = 1000f
    private val virtualH = 500f
    private val playerX = 255f

    private val score: Int
        get() = elapsed.toInt() + runCoins * 100

    private fun saveProgress() {
        prefs.edit()
            .putInt("best", best)
            .putInt("coins", totalCoins)
            .putInt("unlocked", unlockedLevels)
            .apply()
    }

    private fun startRun() {
        elapsed = 0f
        distance = 0f
        worldX = 0f
        nextObstacle = 700f
        nextCoin = 900f
        runCoins = 0
        playerY = 250f
        holding = false
        obstacles.clear()
        coins.clear()
        trail.clear()
        lastFrame = 0L
        screen = Screen.PLAY
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val sx = width / virtualW
        val sy = height / virtualH
        canvas.save()
        canvas.scale(sx, sy)

        val now = System.nanoTime()
        val dt = if (lastFrame == 0L) 0f
            else ((now - lastFrame) / 1_000_000_000f).coerceIn(0f, 0.025f)
        lastFrame = now
        anim += dt

        if (screen == Screen.PLAY) updateGame(dt)

        drawBackdrop(canvas)
        when (screen) {
            Screen.MENU -> drawMenu(canvas)
            Screen.LEVELS -> drawLevels(canvas)
            Screen.WAVES -> drawWaves(canvas)
            Screen.PLAY -> drawGame(canvas)
            Screen.PAUSE -> {
                drawGame(canvas)
                drawOverlay(canvas, "PAUSED", "TAP TO RESUME")
            }
            Screen.DEAD -> {
                drawGame(canvas)
                drawOverlay(canvas, "GAME OVER", "TAP TO RETRY")
            }
            Screen.COMPLETE -> {
                drawGame(canvas)
                drawOverlay(canvas, "LEVEL COMPLETE", "TAP TO CONTINUE")
            }
        }
        canvas.restore()
        postInvalidateOnAnimation()
    }

    private fun updateGame(dt: Float) {
        if (dt <= 0f) return
        val config = levels[levelIndex]
        elapsed += dt
        distance += dt
        worldX += config.speed * dt

        val verticalSpeed = config.speed * 1.45f
        playerY += if (holding) -verticalSpeed * dt else verticalSpeed * dt
        playerY = playerY.coerceIn(112f, 388f)

        trail.add(TrailPoint(playerX, playerY))
        if (trail.size > 24) trail.removeAt(0)

        while (nextObstacle < worldX + 1300f) {
            nextObstacle += Random.nextInt(290, 430).toFloat()
            obstacles.add(Obstacle(nextObstacle, Random.nextBoolean()))
        }
        while (nextCoin < worldX + 1300f) {
            nextCoin += Random.nextInt(420, 700).toFloat()
            coins.add(Coin(nextCoin, Random.nextInt(145, 355).toFloat()))
        }

        obstacles.removeAll { it.x < worldX - 100f }
        coins.removeAll { it.x < worldX - 100f || it.taken }

        checkCollisions()
        if (screen != Screen.PLAY) return

        if (distance >= config.duration) {
            best = max(best, score)
            totalCoins += runCoins
            unlockedLevels = max(unlockedLevels, (levelIndex + 2).coerceAtMost(levels.size))
            saveProgress()
            screen = Screen.COMPLETE
            holding = false
        }
    }

    private fun checkCollisions() {
        val worldPlayerX = worldX + playerX
        val depth = (310f - levels[levelIndex].gap) / 2f

        for (obstacle in obstacles) {
            if (abs(obstacle.x - worldPlayerX) < 24f) {
                val hit = if (obstacle.top) playerY < 95f + depth
                    else playerY > 405f - depth
                if (hit) {
                    endRun()
                    return
                }
            }
        }

        for (coin in coins) {
            if (!coin.taken &&
                abs(coin.x - worldPlayerX) < 32f &&
                abs(coin.y - playerY) < 34f
            ) {
                coin.taken = true
                runCoins++
            }
        }
    }

    private fun endRun() {
        holding = false
        best = max(best, score)
        totalCoins += runCoins
        saveProgress()
        screen = Screen.DEAD
    }

    private fun drawBackdrop(canvas: Canvas) {
        canvas.drawColor(Color.rgb(9, 7, 23))
        for (i in 0..8) {
            paint.color = Color.argb(24, 151, 104, 255)
            val x = ((i * 155f - anim * 20f) % 1150f + 1150f) % 1150f
            canvas.drawCircle(x, 55f + (i % 5) * 95f, 48f, paint)
        }
        paint.color = Color.argb(22, 190, 160, 255)
        paint.strokeWidth = 1f
        for (x in 0..1000 step 50) canvas.drawLine(x.toFloat(), 0f, x.toFloat(), 500f, paint)
        for (y in 0..500 step 50) canvas.drawLine(0f, y.toFloat(), 1000f, y.toFloat(), paint)
    }

    private fun glass(canvas: Canvas, x: Float, y: Float, w: Float, h: Float) {
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(125, 53, 43, 91)
        canvas.drawRoundRect(x, y, x + w, y + h, 22f, 22f, paint)
        paint.color = Color.argb(95, 255, 255, 255)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        canvas.drawRoundRect(x, y, x + w, y + h, 22f, 22f, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(30, 255, 255, 255)
        canvas.drawRoundRect(x + 4f, y + 4f, x + w - 4f, y + 14f, 14f, 14f, paint)
    }

    private fun label(
        canvas: Canvas, value: String, x: Float, y: Float,
        size: Float, color: Int = Color.WHITE, center: Boolean = false
    ) {
        paint.color = color
        paint.textSize = size
        paint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        paint.textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        canvas.drawText(value, x, y, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun button(canvas: Canvas, value: String, x: Float, y: Float, w: Float, h: Float) {
        glass(canvas, x, y, w, h)
        label(canvas, value, x + w / 2f, y + h / 2f + 8f, 20f, Color.WHITE, true)
    }

    private fun drawMenu(canvas: Canvas) {
        label(canvas, "GEOMETRY DASH", 500f, 100f, 34f, Color.WHITE, true)
        label(canvas, "INFINITE WAVE", 500f, 153f, 48f, colors[waveIndex], true)
        label(canvas, "LIQUID GLASS EDITION", 500f, 182f, 15f, Color.LTGRAY, true)
        button(canvas, "PLAY", 300f, 215f, 400f, 65f)
        button(canvas, "LEVELS", 300f, 300f, 190f, 60f)
        button(canvas, "WAVES", 510f, 300f, 190f, 60f)
        label(canvas, "BEST: $best", 500f, 415f, 20f, Color.WHITE, true)
        label(canvas, "TOTAL COINS: $totalCoins", 500f, 450f, 17f, Color.YELLOW, true)
    }

    private fun drawLevels(canvas: Canvas) {
        label(canvas, "SELECT LEVEL", 500f, 72f, 34f, Color.WHITE, true)
        levels.forEachIndexed { i, item ->
            val x = 80f + (i % 3) * 290f
            val y = 115f + (i / 3) * 135f
            glass(canvas, x, y, 250f, 105f)
            val open = i < unlockedLevels
            label(canvas, if (open) "LEVEL ${i + 1}" else "LOCKED",
                x + 125f, y + 43f, 22f,
                if (open) colors[i % colors.size] else Color.GRAY, true)
            label(canvas, item.title, x + 125f, y + 76f, 16f, Color.WHITE, true)
        }
        button(canvas, "BACK", 30f, 425f, 170f, 55f)
    }

    private fun drawWaves(canvas: Canvas) {
        label(canvas, "WAVE COLLECTION", 500f, 75f, 34f, Color.WHITE, true)
        label(canvas, "ALL DESIGNS FREE", 500f, 108f, 15f, Color.LTGRAY, true)
        colors.forEachIndexed { i, color ->
            val x = 100f + (i % 3) * 290f
            val y = 135f + (i / 3) * 140f
            glass(canvas, x, y, 250f, 110f)
            paint.color = color
            paint.strokeWidth = 7f
            paint.strokeCap = Paint.Cap.ROUND
            paint.style = Paint.Style.STROKE
            val path = Path().apply {
                moveTo(x + 75f, y + 55f)
                lineTo(x + 115f, y + 25f)
                lineTo(x + 155f, y + 55f)
            }
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.FILL
            label(canvas, "WAVE ${i + 1}", x + 125f, y + 92f, 17f,
                if (waveIndex == i) color else Color.WHITE, true)
        }
        button(canvas, "BACK", 30f, 425f, 170f, 55f)
    }

    private fun drawGame(canvas: Canvas) {
        paint.color = Color.rgb(111, 75, 180)
        paint.strokeWidth = 3f
        canvas.drawLine(0f, 95f, 1000f, 95f, paint)
        canvas.drawLine(0f, 405f, 1000f, 405f, paint)

        val depth = (310f - levels[levelIndex].gap) / 2f
        for (obstacle in obstacles) {
            val x = obstacle.x - worldX
            if (x !in -60f..1060f) continue
            val path = Path()
            if (obstacle.top) {
                path.moveTo(x - 34f, 95f)
                path.lineTo(x + 34f, 95f)
                path.lineTo(x, 95f + depth)
            } else {
                path.moveTo(x - 34f, 405f)
                path.lineTo(x + 34f, 405f)
                path.lineTo(x, 405f - depth)
            }
            path.close()
            paint.color = Color.rgb(255, 65, 125)
            canvas.drawPath(path, paint)
            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.FILL
        }

        coins.filter { !it.taken }.forEach { coin ->
            val x = coin.x - worldX
            paint.color = Color.rgb(255, 211, 70)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            canvas.drawCircle(x, coin.y, 13f, paint)
            paint.style = Paint.Style.FILL
            label(canvas, "+", x, coin.y + 6f, 17f, Color.WHITE, true)
        }

        for (i in 1 until trail.size) {
            val a = trail[i - 1]
            val b = trail[i]
            paint.color = colors[waveIndex]
            paint.alpha = (i * 10).coerceAtMost(230)
            paint.strokeWidth = 2.5f + i * 0.22f
            paint.strokeCap = Paint.Cap.ROUND
            canvas.drawLine(a.x, a.y, b.x, b.y, paint)
        }
        paint.alpha = 255

        val wave = Path().apply {
            moveTo(playerX - 18f, playerY - 16f)
            lineTo(playerX + 18f, playerY)
            lineTo(playerX - 18f, playerY + 16f)
            close()
        }
        paint.color = colors[waveIndex]
        paint.setShadowLayer(18f, 0f, 0f, colors[waveIndex])
        canvas.drawPath(wave, paint)
        paint.clearShadowLayer()
        paint.color = Color.WHITE
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawPath(wave, paint)
        paint.style = Paint.Style.FILL

        glass(canvas, 15f, 10f, 235f, 70f)
        label(canvas, "SCORE: $score", 29f, 39f, 18f)
        label(canvas, "COINS: $runCoins", 29f, 65f, 15f, Color.YELLOW)

        glass(canvas, 710f, 10f, 270f, 70f)
        label(canvas, "LEVEL ${levelIndex + 1}", 730f, 39f, 18f)
        label(canvas, levels[levelIndex].title, 730f, 65f, 15f, colors[waveIndex])

        glass(canvas, 915f, 88f, 65f, 48f)
        label(canvas, "II", 947f, 120f, 22f, Color.WHITE, true)

        paint.color = Color.DKGRAY
        canvas.drawRoundRect(300f, 22f, 680f, 30f, 8f, 8f, paint)
        paint.color = colors[waveIndex]
        val progress = (distance / levels[levelIndex].duration).coerceIn(0f, 1f)
        canvas.drawRoundRect(300f, 22f, 300f + 380f * progress, 30f, 8f, 8f, paint)
    }

    private fun drawOverlay(canvas: Canvas, title: String, subtitle: String) {
        paint.color = Color.argb(205, 4, 3, 14)
        canvas.drawRect(0f, 0f, 1000f, 500f, paint)
        glass(canvas, 270f, 135f, 460f, 235f)
        label(canvas, title, 500f, 210f, 33f, colors[waveIndex], true)
        label(canvas, subtitle, 500f, 270f, 18f, Color.WHITE, true)
        label(canvas, "SCORE: $score", 500f, 320f, 21f, Color.WHITE, true)
    }

    private fun inside(x: Float, y: Float, l: Float, t: Float, r: Float, b: Float) =
        x >= l && x <= r && y >= t && y <= b

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x * virtualW / width
        val y = event.y * virtualH / height

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                when (screen) {
                    Screen.MENU -> when {
                        inside(x, y, 300f, 215f, 700f, 280f) -> startRun()
                        inside(x, y, 300f, 300f, 490f, 360f) -> screen = Screen.LEVELS
                        inside(x, y, 510f, 300f, 700f, 360f) -> screen = Screen.WAVES
                    }
                    Screen.LEVELS -> {
                        if (inside(x, y, 30f, 425f, 200f, 480f)) {
                            screen = Screen.MENU
                        } else {
                            levels.indices.forEach { i ->
                                val l = 80f + (i % 3) * 290f
                                val t = 115f + (i / 3) * 135f
                                if (inside(x, y, l, t, l + 250f, t + 105f) && i < unlockedLevels) {
                                    levelIndex = i
                                    startRun()
                                }
                            }
                        }
                    }
                    Screen.WAVES -> {
                        if (inside(x, y, 30f, 425f, 200f, 480f)) {
                            screen = Screen.MENU
                        } else {
                            colors.indices.forEach { i ->
                                val l = 100f + (i % 3) * 290f
                                val t = 135f + (i / 3) * 140f
                                if (inside(x, y, l, t, l + 250f, t + 110f)) waveIndex = i
                            }
                        }
                    }
                    Screen.PLAY -> {
                        if (inside(x, y, 910f, 85f, 990f, 145f)) {
                            holding = false
                            screen = Screen.PAUSE
                        } else holding = true
                    }
                    Screen.PAUSE -> {
                        screen = Screen.PLAY
                        lastFrame = 0L
                    }
                    Screen.DEAD -> startRun()
                    Screen.COMPLETE -> {
                        if (levelIndex < levels.lastIndex) levelIndex++
                        screen = Screen.MENU
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                holding = false
                return true
            }
        }
        return true
    }
}
