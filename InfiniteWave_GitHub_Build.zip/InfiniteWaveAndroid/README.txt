INFINITE WAVE — GITHUB APK BUILD
================================

This is the Android source project. GitHub Actions compiles the APK in the
cloud and publishes it as a downloadable workflow artifact.

PROJECT SETTINGS
----------------
Package: com.carter.infinitewave
Minimum Android: 8.0 (API 26)
Language: Kotlin
Android Gradle Plugin: 8.6.1
Gradle: 8.7
JDK: 17
Compile SDK: 35

BUILD FROM YOUR PHONE USING GITHUB
----------------------------------

A. Create the repository
1. Open https://github.com in your phone browser and sign in.
2. Tap +, then New repository.
3. Repository name: InfiniteWave
4. Choose Public or Private. Public is easiest for a personal project.
5. Tap Create repository.

B. Upload the project files
1. Download and extract InfiniteWaveAndroid.zip on your phone.
2. In the new GitHub repository, use Add file > Upload files.
3. Select the extracted project contents, including:
   - settings.gradle.kts
   - build.gradle.kts
   - gradle.properties
   - app/ (including its src/ folder and build.gradle.kts)
   - .github/workflows/build-apk.yml
   IMPORTANT: the .github folder is hidden in some file managers. Enable
   "Show hidden files" before selecting it. If GitHub's mobile uploader
   cannot upload hidden folders, create the workflow manually:
   Add file > Create new file
   File name: .github/workflows/build-apk.yml
   Paste the contents of that file from the extracted project.
4. Scroll down and tap Commit changes.

C. Wait for the APK
1. Open the repository's Actions tab.
2. Select "Build Infinite Wave APK".
3. Open the latest run and wait until it shows a green check.
4. Scroll to Artifacts and tap "InfiniteWave-debug-apk".
5. GitHub downloads a ZIP. Extract it; inside is app-debug.apk.

D. Install
1. Tap app-debug.apk.
2. If Android asks, allow your browser or file manager to install unknown apps.
3. Confirm Install.

BUILD AGAIN
-----------
Every new commit to main starts another build automatically.
You can also open Actions > Build Infinite Wave APK > Run workflow.

TROUBLESHOOTING
---------------
- If Actions is disabled, open the repository's Actions tab and enable
  GitHub Actions for the repository.
- If the run fails, open the run, expand the red failed step, and copy
  the error text so it can be diagnosed.
- The workflow uses JDK 17 and Gradle 8.7, matching Android Gradle
  Plugin 8.6.1 requirements.

IMPORTANT
---------
This ZIP is source code plus the cloud build workflow, not a compiled APK.
The first GitHub run downloads Android/Gradle dependencies and may take
several minutes. The APK artifact is retained for 14 days.
